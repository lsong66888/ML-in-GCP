## Google Cloud Run Deep Dive

Oh hi! These files are used for hands-on labs in the Google Cloud Run Deep Dive course on [acloud.guru](https://acloud.guru/).
